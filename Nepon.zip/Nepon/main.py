from flask import Flask, render_template, request, redirect, url_for
import database

app = Flask(__name__)

@app.route('/')
def main_page():
    filter_by = request.args.get('filter', 'all')
    tasks = database.get_all_tasks(filter_by)
    return render_template('index.html', tasks=tasks, selected=filter_by)


@app.route('/add', methods=['POST'])
def add_task():
    title = request.form['title']
    description = request.form['description']
    database.add_task(title, description)
    return redirect(url_for('main_page'))

@app.route('/delete/<int:id>', methods=['POST'])
def delete_task(id):
    database.delete_task(id)
    return redirect(url_for('main_page'))

@app.route('/update/<int:id>', methods=['GET', 'POST'])
def update_task(id):
    if request.method == 'GET':
        task = database.get_task(id)
        return render_template('update.html', task=task)
    if request.method == 'POST':
        title = request.form['title']
        description = request.form['description']
        done = 'done' in request.form
        database.update_task(id, title, description, done)
        return redirect(url_for('main_page'))

@app.route('/done/<int:id>')
def task_done(id):
    database.task_done(id)
    return redirect(url_for('main_page'))


database.init_db() 
app.run()