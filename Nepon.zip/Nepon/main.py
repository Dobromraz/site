from flask import Flask, render_template, request, redirect, url_for
import database

app = Flask(__name__)

@app.route('/')
def main_page():
    tasks = database.get_all_tasks()
    return  render_template('index.html', tasks=tasks)

@app.route('/add', methods=['POST'])
def add_task():
    title = request.form['title']
    description = request.form['description']
    database.add_task(title, description)
    return redirect(url_for('main_page'))

@app.route('/delete/<int:id>', methods=['POST'])
def delete_task(id):
    database.delete_task(id)
    return redirect(url_for('main_page'))
@app.route('/update/<int:id>', methods=['GET', 'POST'])
def update_task(id):
    if request.method == 'Get':
        task = database.get_task(id)
        return render_template('update.html', task=task)
    if request.method == 'POST':
        title = request.form['title']
        description = request.form['description']
        database.update_task(id, title, description)
        return redirect(url_for('main_page'))
database.init_db() 
app.run()